#!/bin/bash

#
# Script to export the Alflytics repository into a zip file in the current directory.
#

./export-repository.sh "public/Alflytics" "ETL" "Alflytics.ETL"
