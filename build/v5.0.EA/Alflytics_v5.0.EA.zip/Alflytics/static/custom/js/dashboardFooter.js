function dashboardFooter () {

  document.write("@2013-2017 <a href=\"/pentaho/plugin/Alflytics/api/about\" target=\"_blank\">Francesco Corti</a>");

}
