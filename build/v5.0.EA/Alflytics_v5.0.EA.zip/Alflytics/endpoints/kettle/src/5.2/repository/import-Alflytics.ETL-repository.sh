#!/bin/bash

#
# Script to import the ETL repository from a zip file in the current directory.
#

./import-repository.sh "Alflytics.ETL"
