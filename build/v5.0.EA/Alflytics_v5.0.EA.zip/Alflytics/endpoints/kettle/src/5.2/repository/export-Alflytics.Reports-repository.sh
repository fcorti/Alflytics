#!/bin/bash

#
# Script to export the Reports repository into a zip file in the current directory.
#

./export-repository.sh "public/Alflytics" "Reports" "Alflytics.Reports"
