#!/bin/bash

#
# Script to import the Dashboards repository from a zip file in the current directory.
#

./import-repository.sh "Alflytics.Dashboards"
