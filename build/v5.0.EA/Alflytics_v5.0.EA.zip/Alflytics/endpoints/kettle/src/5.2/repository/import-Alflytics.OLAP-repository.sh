#!/bin/bash

#
# Script to import the Reports repository from a zip file in the current directory.
#

./import-repository.sh "Alflytics.OLAP"
